﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Assignment1
{
    public class CustomerData
    {
#nullable enable
        [Column("First Name")]
        public string? FirstName { get; set; }
        [Column("Last Name")]
        public string? LastName { get; set; }
        [Column("Street Number")]
        public string? StreetNumber { get; set; }
        [Column("Street")]
        public string? Street { get; set; }
        [Column("City")]
        public string? City { get; set; }
        [Column("Province")]
        public string? Province { get; set; }
        [Column("Postal Code")]
        public string? PostalCode { get; set; }
        [Column("Country")]
        public string? Country { get; set; }
        [Column("Phone Number")]
        public string? PhoneNumber { get; set; }
        [Column("email Address")]
        public string? emailAddress { get; set; }
    }
}
