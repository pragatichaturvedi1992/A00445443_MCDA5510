﻿using System;
using System.IO;

namespace Assignment1
{


    public class DirWalker
    {

        public void walk(String path)
        {

            string[] list = Directory.GetDirectories(path);


            if (list == null) return;

            foreach (string dirpath in list)
            //foreach (String f : list)
            {
                if (Directory.Exists(dirpath))
                {
                    walk(dirpath);
                    Console.WriteLine("Dir:" + dirpath);
                    SimpleCSVParser par = new SimpleCSVParser();
                    par.Read(dirpath);
                }
            }
            string[] fileList = Directory.GetFiles(path);
            foreach (string filepath in fileList)
            {
                Console.WriteLine("File:" + filepath);
                SimpleCSVParser par = new SimpleCSVParser();
                par.Read(filepath);

            }
        }

        public static void Main(String[] args)
        {
            DirWalker fw = new DirWalker();
            fw.walk(@"C:\Users\DELL\Desktop\MCDA5510_PROJECT\A00445443_MCDA5510\Assignment1\Assignment1\SampleFile");
        }

    }
}
