﻿using System;
using System.Globalization;
using System.IO;
using CsvHelper;
using CsvHelper.Configuration;
using Microsoft.VisualBasic.FileIO;

namespace Assignment1
{
    public class SimpleCSVParser
    {

        public void Read(String fileName)
        {
            Console.WriteLine("Why: "+fileName);

            try
            {
                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    HasHeaderRecord = true,
                    MissingFieldFound = null,
                    BadDataFound = null,
                    Delimiter = ",",
                    
                    
                };
                using StreamReader streamReader = new StreamReader(fileName);
                using CsvReader csvReader = new CsvReader(streamReader, config);

                var customers = csvReader.GetRecords<CustomerData>();
                //string headerLine = streamReader.Readline();
                foreach (var cust in customers)
                {
                    

                    if (string.IsNullOrEmpty(cust.FirstName) || string.IsNullOrEmpty(cust.LastName) || string.IsNullOrEmpty(cust.PhoneNumber)
                        || string.IsNullOrEmpty(cust.PostalCode) || string.IsNullOrEmpty(cust.Province) || string.IsNullOrEmpty(cust.Street)
                        || string.IsNullOrEmpty(cust.StreetNumber) || string.IsNullOrEmpty(cust.City) || string.IsNullOrEmpty(cust.Country)
                        || string.IsNullOrEmpty(cust.emailAddress))
                    {
                       
                    }
                    else
                    {
                        Console.WriteLine(cust);
                    }

                }

            }
            catch (IOException ioe)
            {
                Console.WriteLine(ioe.StackTrace);
            }

        }


    }
}
